<?php
/*
Plugin Name: Footer Radio Player
Plugin URI: https://github.com/Heimatradio/Footer-Radio-Player-2.0.0-Modular-Architecture-Release
Description: A customizable sticky footer radio player supporting Shoutcast and Icecast streams.
Version: 2.0.1
License: GPL v2
Author: Martin Sievers
Author URI: https://heimatradio.com
Text Domain: footer-radio-player
*/

if (!defined('ABSPATH')) {
    exit;
}

define('FRP_VERSION', '2.0.1');
define('FRP_PATH', plugin_dir_path(__FILE__));
define('FRP_URL', plugin_dir_url(__FILE__));

require_once FRP_PATH . 'includes/class-frp-core.php';

FRP_Core::instance();
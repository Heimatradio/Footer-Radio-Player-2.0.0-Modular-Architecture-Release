# Changelog

All notable changes to this project will be documented in this file.

This project follows Semantic Versioning.

---

## [2.0.0] - 2026-03-01

### Added
- Modular architecture (Core / Admin / Frontend)
- Popup player rebuild
- Live title AJAX handling
- Scrollable radio text
- Dynamic cover artwork via iTunes API
- Desktop-only volume slider
- Copy-to-clipboard popup generator
- Improved Icecast multi-mount handling

### Changed
- Refactored legacy monolithic structure into class-based system
- Improved code organization and maintainability

### Fixed
- DOCTYPE AJAX bug in popup
- Icecast title parsing issues
- Media uploader fallback handling

---

## [1.5.6] - Stable Legacy Version

### Added
- Popup generator
- Scroll animation
- Custom play button
- Cover fade transition
- Color customization

---

## [1.5.0 - 1.5.5]

### Improvements
- UI refinements
- Cover art support
- Volume control
- Stability fixes